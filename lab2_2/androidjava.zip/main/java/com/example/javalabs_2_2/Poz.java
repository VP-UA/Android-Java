package com.example.javalabs_2_2;

public class Poz {
}
